
from pathlib import Path
import sqlite3

from fastapi import FastAPI, HTTPException
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field

BASE_DIR = Path(__file__).resolve().parent
DB_PATH = BASE_DIR / "runs.db"

app = FastAPI(title="Mini Strava API")

# Database connection
def connect_db():
    return sqlite3.connect(DB_PATH)

# Create database table
with connect_db() as db:
    db.execute("""
        CREATE TABLE IF NOT EXISTS runs (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            date TEXT,
            distance REAL,
            duration REAL
        )
    """)

# Data validation
class Run(BaseModel):
    date: str
    distance: float = Field(gt=0)
    duration: float = Field(gt=0)

# Serve frontend files
app.mount("/static", StaticFiles(directory=BASE_DIR / "static"), name="static")

@app.get("/")
def home():
    return FileResponse(BASE_DIR / "static" / "index.html")

# Get all running records
@app.get("/api/runs")
def get_runs():
    with connect_db() as db:
        db.row_factory = sqlite3.Row
        rows = db.execute(
            "SELECT * FROM runs ORDER BY id DESC"
        ).fetchall()

        return {"runs": [dict(row) for row in rows]}

# Add a running record
@app.post("/api/runs")
def add_run(run: Run):
    with connect_db() as db:
        cursor = db.execute(
            """INSERT INTO runs (date, distance, duration)
               VALUES (?, ?, ?)""",
            (run.date, run.distance, run.duration)
        )

        return {
            "message": "Run saved",
            "id": cursor.lastrowid
        }

# Delete a running record
@app.delete("/api/runs/{run_id}")
def delete_run(run_id: int):
    with connect_db() as db:
        cursor = db.execute(
            "DELETE FROM runs WHERE id = ?",
            (run_id,)
        )

        if cursor.rowcount == 0:
            raise HTTPException(status_code=404, detail="Run not found")

        return {"message": "Run deleted"}

# Running statistics
@app.get("/api/summary")
def summary():
    with connect_db() as db:
        count, distance, duration = db.execute("""
            SELECT COUNT(*), COALESCE(SUM(distance), 0),
                   COALESCE(SUM(duration), 0)
            FROM runs
        """).fetchone()

        return {
            "total_runs": count,
            "total_distance": distance,
            "average_pace": duration / distance if distance else 0
        }
