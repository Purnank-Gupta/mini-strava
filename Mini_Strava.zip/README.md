
# Mini Strava

A beginner-friendly running tracker built using Python and FastAPI.

## Features

- Add running activities
- Calculate running pace
- View running history
- Delete running activities
- Track total running distance

## Technologies

- Python
- FastAPI
- SQLite
- HTML
- CSS
- JavaScript

## Run locally

Install dependencies:

pip install -r requirements.txt

Start the server:

uvicorn main:app --reload

Open http://127.0.0.1:8000
